import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

public class Obstacle extends JComponent {
    int x=0;
    int y=0;
    int dx = 5;
    int dy = 5;
    int SIZEX = 400;
    int SIZEY = 600;
    BufferedImage image;

    public Obstacle(int x, int y, int dx, int dy, BufferedImage image) throws IOException {
        this.x = x;
        this.y = y;
        this.dx = dx;
        this.dy = dy;
        this.image = image;
    }


    @Override
    public void paint(Graphics g) {
        try {
            BufferedImage imagew = ImageIO.read(new File("src/bomb.png"));
            g.drawImage(imagew, x, y, this);
        } catch (IOException e) {
            System.out.printf("An exception happened! %s\n", e.getMessage());
        }
        //super.paint(g);
    }

        void moveObs(int dx, int dy) {
            if( y + dx > SIZEX || x + dx < 0) {
                dx = -dx;
            }

            if( x + dy > SIZEY || y + dy < 0) {
                dy = -dy;
            }

            x += dx;
            y += dy;
        }
}
