public class DeepDishPizza extends Pizza{

}
