import javax.swing.*;
import java.awt.*;

public class DrawnShapeComponent extends JComponent {
    // Constants. Make sure to reference these elsewhere and not hard code numbers!
    public static final int CIRCLE_CODE = 1;
    public static final int SQUARE_CODE = 2;

    // Instance variables
    private final int shapeCode;
    private final boolean isRed, isBlue;

    // TODO give the constructor which assigns all three instance variables to the parameters

    // TODO add getters for the three instance variables. Let IntelliJ do this for you with right-click > Generate...

    // TODO implement the method which draws this component in a certain way.
    //      it should depend on the instance variables for conditionally deciding what to draw and how.
    //      Hint: start with assigning the Graphics instance's color based on the booleans,
    //      then use .fillArc or .fillRect based on the shape code. For both, use coordinates of (0, 0) and the dimensions
    //      from ShapeConfigurationDisplay's constant Dimension member
}
