public class Test {
    public static void main(String[] args)
    {
        DrawnImageComponent p1 = new DrawnImageComponent();
        p1.isDisplayable();
    }
}
