import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner in = new Scanner(System.in);

        System.out.print("Enter a floor: ");
        int number = in.nextInt();

        int floor;

//            The conditional if
//        floor = number>13?number-2:number;

        
//        if(number>13)
//        {
//            floor = number - 2;
//
//        }
//        else
//        {
//            floor = number;
//        }
        System.out.println("The floor value is : ");





//        System.out.print("Enter the original price: ");
//        int number = in.nextInt();
//
//        int discountedPrice;
//        if(number > 100)
//        {
//            discountedPrice = number - 20;
//        }
//        else
//        {
//            discountedPrice = number - 10;
//        }
//
//        System.out.println(discountedPrice);



    }
}