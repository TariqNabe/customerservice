import java.util.Scanner;
public class TaskSix {
    public static void main(String[] args)
    {
            Scanner in = new Scanner(System.in);
            System.out.println("Enter word");
            String name = in.nextLine();
               
            name1(name);
           
         }

         public static String name1(String name)
         {
          for(int i=0; i< name.length(); i++)
         {
            System.out.println(name.charAt(i));
         }
         return name;
         }
    }

